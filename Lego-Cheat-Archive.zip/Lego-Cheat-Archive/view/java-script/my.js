document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.collapsible');
    var instances = M.Collapsible.init(elems);
  });

document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.sidenav');
    var instances = M.Sidenav.init(elems);
  });

  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.modal');
    var instances = M.Modal.init(elems);
  });

  populateGames();

  function populateGames() {
    var HTMLCode = '';
    var url = '../model/WebService.php?req=games';
    var HTMLTemplate = games_head.innerHTML;
    fetch(url, {
        method: 'get',
        credentials: 'include'
        })
        .then(
            function(response) {
                if (response.status !== 200) {
                    console.log('Looks like there was a problem. Status Code: ' +
                      response.status);
                    return;
                }
                // Examine the text in the response
                response.json().then(function(data) {
                  console.log(data);
                  var number = 0;
                  for(loop=0;loop<data.length;loop++) {
                      number ++;
                      HTMLCode += HTMLTemplate.replace(/{{gameTitle}}/g, data[loop].gameTitle)
                      .replace(/{{gamePic}}/g, data[loop].gamePic)
                      .replace(/{{number}}/g, number); 
                }
                    game_list.innerHTML = HTMLCode;
                });
            }
        )
        .catch(function(err) {
        console.log('Fetch Error :-S', err);
    });  
}

if(localStorage.getItem('UserID') !== null) {
  fetchUser();
}
else {
}

function fetchUser() {
  var HTMLCode = '';
  var url = '../model/WebService.php?req=user';
  fetch(url, {
      method: 'get',
      credentials: 'include'
      })
      .then(
          function(response) {
              if (response.status !== 200) {
                  console.log('Looks like there was a problem. Status Code: ' +
                    response.status);
                  return;
              }
              // Examine the text in the response
              response.json().then(function(data) {
                console.log(data);
              });
          }
      )
      .catch(function(err) {
      console.log('Fetch Error :-S', err);
  });  
}

document.getElementById('accountDelete').addEventListener("submit", function(userDelete) {deleteAccount(userDelete)});

function deleteAccount(event) {
  event.preventDefault();
  var url = '../model/WebService.php?req=delUser';
  fetch(url, {
      method: 'get',
      credentials: 'include'
      })
      .then(
          function(response) {
              if (response.status !== 200) {
                  console.log('Looks like there was a problem. Status Code: ' +
                    response.status);
                  return;
              }
              // Examine the text in the response
              response.json().then(function(data) {
                console.log(data);
                if(data.Message == 'No user to delete') {
                  M.toast({html: 'No user could be deleted', displayLength: 5000});
                  document.getElementById("toast-container").addEventListener("click", dismiss);
                }
                else {
                  M.toast({html: 'Account deleted', displayLength: 5000});
                  document.getElementById("toast-container").addEventListener("click", dismiss);
                }
              });
          }
      )
      .catch(function(err) {
      console.log('Fetch Error :-S', err);
  });  
}

document.getElementById('usernameUpdate').addEventListener("submit", function(userUpdate) {updateUser(userUpdate)});

function updateUser(event) {
  console.log('This is the update function')
  event.preventDefault();
  var url = "../model/WebService.php?req=updateUser&updateAccount="+updateAccount.value+" ";
  fetch(url, {
      method: 'get',
      credentials: 'include'
      })
      .then(
          function(response) {
              if (response.status !== 200) {
                  console.log('Looks like there was a problem. Status Code: ' +
                    response.status);
                  return;
              }
              // Examine the text in the response
              response.json().then(function(data) {
                console.log(data);
                if(data.Message == 'No user to Update') {
                  M.toast({html: 'No User to update', displayLength: 5000});
                  document.getElementById("toast-container").addEventListener("click", dismiss);
                }
                else {
                  M.toast({html: 'User Updated', displayLength: 5000});
                  document.getElementById("toast-container").addEventListener("click", dismiss);
                }
              });
          }
      )
      .catch(function(err) {
      console.log('Fetch Error :-S', err);
  });
}

function dismiss() {
  var toastElement = document.querySelector('.toast');
  var toastInstance = M.Toast.getInstance(toastElement);
  toastInstance.dismiss();
}

if(localStorage.getItem('background') !== null) {
  document.body.style.background = localStorage.getItem('background');
  document.body.style.color = localStorage.getItem('text');
  document.getElementById('slide-out').style.background = localStorage.getItem('background')
  document.getElementById('slide-out').style.color = localStorage.getItem('text')
  var style = document.createElement('style');
  style.innerHTML = localStorage.getItem('style')
  document.head.appendChild(style);
}

if(localStorage.getItem('background') == 'black') {
  backColor.checked = true;
}

function changeColor() {
  if(backColor.checked == true) {
      window.localStorage.setItem('background','black');
      window.localStorage.setItem('text','white');
      window.localStorage.setItem('style', `      
      .theme {
        background-color: black;
        border: solid white 1px;
      }
      input {
        color: white;
      }
      .modal {
        background-color: black;
      }
      .modal .modal-footer {
        background-color: black; 
      }
      .collapsible-header {
        background-color: black;
      }
      .waves-button-input {
        color: white;
      }
      .sidenav li>a {
        color: white;
      }`);
      document.body.style.background = 'black';
      document.body.style.color = 'white';
      document.getElementById('slide-out').style.background = 'black';
      document.getElementById('slide-out').style.color = 'white';
      var style = document.createElement('style');
      style.innerHTML = `
      .theme {
        background-color: black;
        border: solid white 1px;
      }
      input {
        color: white;
      }
      .modal {
        background-color: black;
      }
      .modal .modal-footer {
        background-color: black; 
      }
      .collapsible-header {
        background-color: black;
      }
      .waves-button-input {
        color: white;
      }
      .sidenav li>a {
        color: white;
      }`;
      document.head.appendChild(style);
  }
  else {
      window.localStorage.setItem('background','white');
      window.localStorage.setItem('text','black');
      window.localStorage.setItem('style', `
      .theme {
        background-color: white;
      }
      input {
        color: black;
      }
      .modal {
        background-color: white;
      }
      .modal .modal-footer {
        background-color: white; 
      }
      .collapsible-header {
        background-color: white;
      }
      .waves-button-input {
        color: black;
      }
      .sidenav li>a {
        color: black;
      }`);
      document.body.style.background = 'white';
      document.body.style.color = 'black';
      document.getElementById('slide-out').style.background = 'white';
      document.getElementById('slide-out').style.color = 'black';
      var style = document.createElement('style');
      style.innerHTML = `
      .theme {
        background-color: white;
      }
      input {
        color: black;
      }
      .modal {
        background-color: white;
      }
      .modal .modal-footer {
        background-color: white; 
      }
      .waves-button-input {
        color: black;
      }
      .collapsible-header {
        background-color: white;
      }
      .sidenav li>a {
        color: black;
      }`;
      document.head.appendChild(style);
  }
}

function showGames() {
  var Games = document.getElementById('game_list');
  Games.style.display = 'block';
  var postsList = document.getElementById('posts_list');
  postsList.style.display = 'none';
  var cheatList = document.getElementById('game_cheats');
  cheatList.style.display = 'none';
  var Title = document.getElementById('Title');
  Title.style.display = 'none';
}

function gamePage(gameID) {
  console.log(gameID);
  var Games = document.getElementById('game_list');
  Games.style.display = 'none';
  var postsList = document.getElementById('posts_list');
  postsList.style.display = 'block';
  var cheatList = document.getElementById('game_cheats');
  cheatList.style.display = 'block';
  var Title = document.getElementById('Title');
  Title.style.display = 'block';
  if (localStorage.getItem('Login') == 'True') {
    var Post_Col = document.getElementById('Post_Col');
    Post_Col.style.display = 'block';
  }
  else {
    var Post_Col = document.getElementById('Post_Col');
    Post_Col.style.display = 'none';
  }
  var url = "../model/WebService?Cheats="+gameID+"";
  var gameCode = '';
  var HTMLTemplate = cheat_page.innerHTML;
  fetch(url, {
    method: 'get',
    credentials: 'include'
    })
    .then(
        function(response) {
            if (response.status !== 200) {
                console.log('Looks like there was a problem. Status Code: ' +
                  response.status);
                return;
            }
            // Examine the text in the response
            response.json().then(function(data) {
              console.log(data);
              for(loop=0;loop<data.length;loop++) {
                gameCode += HTMLTemplate.replace(/{{PostTitle}}/g, data[loop].postTitle)
                  .replace(/{{date}}/g, data[loop].date)
                  .replace(/{{postDescription}}/g, data[loop].postDescription)
                  .replace(/{{userPic}}/g, data[loop].profilePicture);
          }
              game_cheats.innerHTML = gameCode;
              localStorage.setItem('ThreadID',data[0].threadID);
              cheatGameTitle.innerHTML = data[0].gameTitle;
              cheatBackground.setAttribute('style', 'background-image: url("'+data[0].gamePic+'");');
            });
        }
    )
    .catch(function(err) {
    console.log('Fetch Error :-S', err);
});
}


document.getElementById('Login').addEventListener("submit", function(e) {Login(e)});

function Login(e) {
  e.preventDefault();
  const url = '../model/WebService.php';
  const formData = new FormData(document.getElementById('Login'));
  formData.append('signin','login');
  fetch(url, {
    method: 'POST',
    credentials: 'include',
    body: formData
    })
    .then(
        function(response) {
            if (response.status !== 200) {
                console.log('Looks like there was a problem. Status Code: ' +
                  response.status);
                return;
            }
            // Examine the text in the response
            response.json().then(function(data) {
              console.log(data);
              if(data.Login == 'Failure') {
                M.toast({html: 'Username or Password is incorrect', displayLength: 5000});
                document.getElementById("toast-container").addEventListener("click", dismiss);
                document.getElementsByTagName('a')[3].click();
              }
              else {
                M.toast({html: 'Successfully Logged in', displayLength: 5000});
                document.getElementById("toast-container").addEventListener("click", dismiss);
                localStorage.setItem('UserID', data.UserID); 
                localStorage.setItem('DisplayName', data.DisplayName);
                localStorage.setItem('Login', 'True');
                document.getElementById('closelog').style.display = 'none';
                document.getElementById('closereg').style.display = 'none';
                document.getElementById('divi1').style.display = 'none';
                document.getElementById('divi2').style.display = 'none';
              }
            });
        }
    )
    .catch(function(err) {
    console.log('Fetch Error :-S', err);
  });
}

document.getElementById('reg').addEventListener("submit", function(e) {Register(e)});

function Register(e) {
  e.preventDefault();
  const url = '../model/WebService.php';
  const formData = new FormData(document.getElementById('reg'));
  formData.append('form_id','register');
  fetch(url, {
    method: 'POST',
    credentials: 'include',
    body: formData
    })
    .then(
        function(response) {
            if (response.status !== 200) {
                console.log('Looks like there was a problem. Status Code: ' +
                  response.status);
                return;
            }
            // Examine the text in the response
            response.json().then(function(data) {
              console.log(data);
              if(data.Message == 'Registration success') {
                M.toast({html: 'Successfully Registered', displayLength: 5000});
                document.getElementById("toast-container").addEventListener("click", dismiss);
              }
              else {
                document.getElementsByTagName('a')[4].click();
                M.toast({html: 'Registration Failure', displayLength: 5000});
                document.getElementById("toast-container").addEventListener("click", dismiss);
              }
            });
        }
    )
    .catch(function(err) {
    console.log('Fetch Error :-S', err);
  });
}

document.getElementById('logout').addEventListener("click", function(e) {logout(e)});

function logout() {
  var url = '../model/destorySession.php';
  fetch(url, {
    method: 'GET',
    credentials: 'include',
    })
    .then(
        function(response) {
            if (response.status !== 200) {
                console.log('Looks like there was a problem. Status Code: ' +
                  response.status);
                return;
            }
            // Examine the text in the response
            response.json().then(function(data) {
              console.log(data);
              localStorage.removeItem('UserID');
              localStorage.removeItem('DisplayName');
              localStorage.removeItem('Login');
              document.getElementById('closelog').style.display = 'block';
              document.getElementById('closereg').style.display = 'block';
              document.getElementById('divi1').style.display = 'block';
              document.getElementById('divi2').style.display = 'block';
              
            });
        }
    )
}

document.getElementById('posts').addEventListener("submit", function(e) {Post(e)});

function Post(e) {
  if (localStorage.getItem('Login') == 'True') {
    e.preventDefault();
    var threadID = localStorage.getItem('ThreadID');
    var UserID = localStorage.getItem('UserID');
    console.log(threadID);
    const url = '../model/WebService.php';
    const formData = new FormData(document.getElementById('posts'));
    formData.append('form_id','posts');
    formData.append('ThreadID',threadID);
    formData.append('UserID', UserID);
    fetch(url, {
      method: 'POST',
      credentials: 'include',
      body: formData
      })
      .then(
          function(response) {
              if (response.status !== 200) {
                  console.log('Looks like there was a problem. Status Code: ' +
                    response.status);
                  return;
              }
              // Examine the text in the response
              response.json().then(function(data) {
                console.log(data);
                if (data.Error) {
                  M.toast({html: 'You have entered in-vaild characters', displayLength: 5000});
                  document.getElementById("toast-container").addEventListener("click", dismiss);
                }
                else {
                  M.toast({html: 'Post Created', displayLength: 5000});
                  document.getElementById("toast-container").addEventListener("click", dismiss);
                  posts.reset();
                }
              });
          }
      )
      .catch(function(err) {
      console.log('Fetch Error :-S', err);
    });
  }
  else {
    e.preventDefault();
    M.toast({html: "You can't create a post without being logged in", displayLength: 5000});
    document.getElementById("toast-container").addEventListener("click", dismiss);
  }
}

if(localStorage.getItem('Login') == 'True') {
  document.getElementById('closelog').style.display = 'none';
  document.getElementById('closereg').style.display = 'none';
  document.getElementById('divi1').style.display = 'none';
  document.getElementById('divi2').style.display = 'none';
}