<?php
Session_start();
session_unset();
Session_destroy();
echo json_encode(Array('Session' => 'Has been destoryed'));
?>