<?php
    class sessionManager {
        private $last_times = Array();
        private $last_times2 = Array();
        private $first_time;
        private $first_time2;

        public function __construct() {
        }

        public function rateLimit1Sec() {
            array_push($this->last_times, time());
            $count = 0;
            foreach($this->last_times as $item) {
                $this_time = time();
                $count ++;
                // So here it's checking to see if the current time to the same as the time that was taken
                // In the last request, so if 1 = 1 and the count is how many requests I can sent in
                // Before the program dies
                try {
                    if($this->first_time > ($this_time - 1) && $count > 3) {
                        throw new Exception("Rate limit Exceeded");
                        unset($this->last_times);
                    }
                    else if ($count > 5) {
                        unset($this->last_times); 
                    }
                }
                catch (Exception $e) {
                    echo json_encode(Array('Caught Exception: '. $e->getMessage()));
                    die();
                }
            }
            $this->first_time = time();
        }
        public function check_24h() {
            array_push($this->last_times2, time());
            $count = 0;
            foreach($this->last_times2 as $item) {
                $this_time2 = time();
                $count ++;
                try{
                    if($this->first_time2 > ($this_time2 - 86400) && $count > 10000) {
                        throw new Exception("Rate limit exceeded");
                    }
                }
                catch (Exception $e) {
                    echo json_encode(Array('Caught Exception: '. $e->getMessage()));
                    die();
                }
            }
            if ($this->first_time2 < ($this_time2 - 86400)) {
                unset($this->last_times2);
            }
            $this->first_time2 = time();
        }

        public function refererCheck() {
            if(!isset($_SERVER['HTTP_REFERER'])) {
               echo json_encode(Array('Error' => 'The server has deemed you un-worthy of view the sacred texts'));
               return false; 
            }
            else {
                return true;
            }
        }

        public function domainLock() {
            if(preg_match('/model/', $_SERVER['REQUEST_URI'])) {
                return true;
            }
            else {
                return false;
            }
        }

        public function sendLogs($sessID) {
            $Database = new Database;
            $Database->insertLogs($sessID);
        }

        public function assignLogin($username, $row) {
            $_SESSION["username"] = $username;
            $_SESSION["loginID"] = $row["userID"];
            $_SESSION["access"] = $row["role"];
            $_SESSION['displayName'] = $row['displayName'];
            $_SESSION['Picture'] = $row['profilePicture'];
            $_SESSION["login"] = true;
        }
    }
?>