<?php
    class Database {
        private $conn;

        public function __construct() {
            $dbusername = "root";
            $dbpassword = "";
            $this->conn = new PDO("mysql:host=localhost;dbname=lego_cheat_archive",$dbusername,$dbpassword);
        }
        public function Registration($displayName, $username, $password, $email, $userRole, $profilePicture) {
            try {
                $stmt = $this->conn->prepare("INSERT INTO users (displayName, username, password, email, role, profilePicture)
                VALUES (:disname, :user, :pass, :email, :role, :pic)");
                $stmt->bindValue(':disname', $displayName);
                $stmt->bindValue(':user', $username);
                $stmt->bindValue(':pass', $password);
                $stmt->bindValue(':email', $email);
                $stmt->bindValue(':role', $userRole);
                $stmt->bindValue(':pic', $profilePicture);
                $stmt->execute();
            }
            catch (PDOException $ex) {
                throw $ex;
            }
        }
        public function passwordHash($displayName, $username, $mypass, $email, $userRole, $profilePicture) {
            $password= password_hash($mypass, PASSWORD_DEFAULT);
            $query = $this->conn->prepare( "SELECT username FROM users WHERE Username = :user");
            $query->bindValue( ":user", $username);
            $query->execute();
            if ($query->rowCount() < 1 ) {
                try{
                    $this->Registration($displayName, $username, $password, $email, $userRole, $profilePicture);
                }
                catch(Exception $ex) {
                    echo json_encode(Array('Err' => 'Action could not be completed'));
                    die();
                }
            }
        }

        public function getGames() {
            $stmt = $this->conn->prepare('SELECT gameTitle, gameGenre, gameReleaseDate, 
            gameDescription, gamePic FROM games');
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($result);
        }
        public function login($username, $password) {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE username=:user");
            $stmt->bindParam(':user', $username);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $arr = Array('UserID' => $row['userID'], 'DisplayName' => $row['displayName']);
            // Password verification
            if (password_verify($password, $row['password'])){
                $_SESSION['Sess']->assignLogin($username, $row);
                echo json_encode($arr);
            }
            else {
                echo json_encode(Array('Login' => 'Failure'));
            }
        }
        public function insertLogs($sessID) {
            try {
            $stmt = $this->conn->prepare("INSERT INTO serverlogs (Referrer, SourceIP, TimeStamp, sessionID, requestedURL, method)
            VALUES (:referrer, :ip, CURRENT_TIMESTAMP, :sessID, :requested, :method)");
            $stmt->bindValue(':referrer', $_SERVER['HTTP_REFERER']);
            $stmt->bindValue(':ip', $_SERVER['REMOTE_ADDR']);
            $stmt->bindValue(':sessID', $sessID);
            $stmt->bindValue(':requested', $_SERVER['REQUEST_URI']);
            $stmt->bindValue(':method', $_SERVER['REQUEST_METHOD']);
            $stmt->execute();
            }
            catch (PDOException $ex) {
                throw $ex;
            }
        }

        public function deleteUser($UserID) {
            try {
                $stmt = $this->conn->prepare("DELETE FROM users WHERE userID = :userID");
                $stmt->bindValue(':userID', $UserID);
                $stmt->execute();
                echo json_encode(Array('Message' => 'User was deleted'));
            }
            catch (PDOException $ex) {
                throw $ex;
            }
        }

        public function updateUser($displayName, $UserID) {
            try {
                $stmt = $this->conn->prepare("UPDATE users SET displayName = :displayName WHERE userID = :userID");
                $stmt->bindValue(':displayName', $displayName);
                $stmt->bindValue(':userID', $UserID);
                $stmt->execute();
                echo json_encode(Array('Message' => 'User was Updated'));
            }
            catch (PDOException $ex) {
                throw $ex;
            }
        }
        
        public function createGame($gameTitle, $gameGenre, $releaseDate, $gameDes, $gamePic) {
            try {
                $stmt = $this->conn->prepare("INSERT INTO games (gameTitle, gameGenre, gameReleaseDate, gameDescription, gamePic)
                VALUES (:gameT, :gameG, :gameRel, :gameDes, :GamePic)");
                $stmt->bindValue(':gameT', $gameTitle);
                $stmt->bindValue(':gameG', $gameGenre);
                $stmt->bindValue(':gameRel', $releaseDate);
                $stmt->bindValue(':gameDes', $gameDes);
                $stmt->bindValue(':GamePic', $gamePic);
                $stmt->execute();
            }
            catch (PDOException $ex) {
                throw $ex;
            }   
        }

        public function showCheats($GameID) {
            try {
                $stmt = $this->conn->prepare("SELECT platform.platformName, posts.postTitle, posts.postDescription, posts.date, games.gameTitle, games.gamePic, 
                                              posts.threadID, users.profilePicture
                                              FROM threads
                                              INNER JOIN platform ON threads.platformID = platform.platformID
                                              RIGHT JOIN posts ON threads.threadID = posts.threadID
                                              RIGHT JOIN games ON threads.gameID = games.gameID
                                              INNER JOIN users ON posts.userID = users.userID
                                              WHERE games.gameID = :GameID");
                $stmt->bindValue(':GameID', $GameID);
                $stmt->execute();
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (empty($result)) {
                    echo json_encode(Array('Error' => 'No data found'));
                    return false;
                }
                else {
                    echo json_encode($result);
                }
            }
            catch(PDOException $ex) {
                throw $ex;
            }
        }
        function createPost($postTitle, $postDes, $threadID, $UserID) {
            try{
                $stmt = $this->conn->prepare("INSERT INTO posts (postTitle, postDescription, date, rating, userID, threadID)
                                              VALUES (:postT, :postD ,CURRENT_DATE, '0', :user, :thread)");
                $stmt->bindValue(':postT', $postTitle);
                $stmt->bindValue(':postD', $postDes);
                $stmt->bindValue(':thread', $threadID);
                $stmt->bindValue(':user', $UserID);
                $stmt->execute();
            }
            catch (PDOException $ex) {
                throw $ex;
            } 
        }
    }
?>