<?php

$string = "Then what the fuck??!?!!";

if (preg_match('/[\'^£$%&*()}{@#~><>,|=_+¬-]/', $string))
{
    echo('one or more of the special characters found in');
}
else {
    echo $string;
}

?>