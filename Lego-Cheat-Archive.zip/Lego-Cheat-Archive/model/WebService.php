<?php
include('dbobjec.php');
include('sessobjec.php');
include('WSUtil.php');
session_start();

// This is where I have instantiated the database and session objects
// Because it is the first little piece of code that is going to fire
// it's needed for the rest of the cases and so forth
$Database = new Database;
$Util = new Utilities;
// This is where I am checking to see if the session pre-exists
// And if it doesn't exist then make a new sessions "Sess"
// And assign the session object
if(!isset($_SESSION['Sess'])) {
    $_SESSION['Sess'] = new sessionManager;
}
else {
}
$_SESSION['Sess']->rateLimit1Sec();
$_SESSION['Sess']->check_24h();
if($_SESSION['Sess']->refererCheck() == false and $_SESSION['Sess']->domainLock() == false) {
    die;
}
$sessID = session_id();
$_SESSION['Sess']->sendLogs($sessID);

// This is a switch case structure that is being used to send all my GET requests
// To the web service
if(isset($_GET['req'])){
    switch($_GET['req']) {
        case 'games':
            $Database->getGames();
        break;
        case 'user':
            if(isset($_SESSION['login'])){
                if($_SESSION['login'] == true) {
                    $userArr = Array('UserID' => $_SESSION['loginID'], 'username' => $_SESSION['displayName']);
                    echo json_encode($userArr);
                } 
                else {
                }
            }
            else {
                echo json_encode(Array('Message' => 'Sign in to gain more features'));
            }
        break;
        case 'delUser':
            if(isset($_SESSION['login'])) {
                if($_SESSION['login'] == true) {
                    $UserID = $_SESSION['loginID'];
                    $Database->deleteUser($UserID);
                }
            }
            else {
                echo json_encode(Array('Message' => 'No user to delete'));
            }
        break;
        case 'updateUser':
            if(isset($_SESSION['login'])) {
                if($_SESSION['login'] == true) {
                    $UserID = $_SESSION['loginID'];
                    if(isset($_GET['updateAccount'])) {
                        $displayName = $_GET['updateAccount'];
                    }
                    else {
                        echo json_encode(Array('Err' => 'No user entered'));
                    }
                    $Database->updateUser($displayName, $UserID);
                }
            }
            else {
                echo json_encode(Array('Message' => 'No user to Update'));
            }
            break;
        default:
            echo json_encode(Array('Err' => 'No parameters'));
        break;
    }
// This is also a switch case structure that is sending all my Post requests to the database
} else if(isset($_POST['form_id'])) {
    switch($_POST['form_id']) {
        case 'register':
        if (!empty($_POST)) {
            // Validation process
            $valname = $_POST['Display_name'];
            $valemail = $_POST['Email'];
            if($Util->Validation($valname,'alnum') == true && $Util->Validation($valemail,'email') == true) {
                //input sanitation via testInput function
                $defualtImg = 'images/img.png';
                $displayName = !empty($valname)? $Util->inputFilter(($valname)): null;
                $username = !empty($_POST['Username'])? $Util->inputFilter(($_POST['Username'])): null;
                $mypass = !empty($_POST['Password'])? $Util->inputFilter(($_POST['Password'])): null;
                $email = !empty($valemail)? $Util->inputFilter(($valemail)): null;
                $userRole = !empty($_POST['User_role'])? $Util->inputFilter(($_POST['User_role'])): null;
                $profilePicture = !empty($_POST['Profile_picture'])? $Util->inputFilter(($_POST['Profile_picture'])): $defualtImg;
                $Database->passwordHash($displayName, $username, $mypass, $email, $userRole, $profilePicture);
                echo json_encode(Array('Message' => 'Registration success'));
            }
            else {
                echo json_encode(Array('Error'=>'Dirty String found'));
            }
        }
        else {
            echo json_encode(Array('Error' => 'There is no post data'));
        }
        break;
        case 'posts':
            if(!empty($_POST)) {
                // Validation process 
                $valTitle = $_POST['postTitle'];
                $valDes = $_POST['postDes'];
                if (!isset($_POST['UserID'])) {
                    echo json_encode(Array('Error' => 'No User found'));
                    die();
                }
                if($Util->Validation($valTitle,'alnum') == true && $Util->Validation($valDes,'alnum') == true) {
                    $UserID = $_POST['UserID'];
                    $threadID = $_POST['ThreadID'];
                    $postTitle = !empty($_POST['postTitle'])? $Util->inputFilter(($_POST['postTitle'])): null;
                    $postDes = !empty($_POST['postDes'])? $Util->inputFilter(($_POST['postDes'])): null;
                    $Database->createPost($postTitle, $postDes, $threadID, $UserID);
                    echo json_encode(Array('Message' => 'Post added'));
                }
                else {
                    echo json_encode(Array('Error'=>'Dirty String found'));
                }
            }
            else {
                echo json_encode(Array('Error' => 'There is no post data'));
            }
        break; 
        default:
            echo json_encode(Array('Error' => "I don't see anything here"));
        break;
    }
}
else if(isset($_POST['signin'])){
    switch($_POST['signin']) {
        case 'login':
        if(!empty($_POST)) {
            // No validation needed as its a username and password
            $username = !empty($_POST['loginUsername'])? $Util->inputFilter(($_POST['loginUsername'])): null;
            $password = !empty($_POST['loginPassword'])? $Util->inputFilter(($_POST['loginPassword'])): null;
            try {
                $Database->login($username, $password);
            }
            catch(PDOexception $e) {
                echo json_encode(Array('Err' => 'Action could not be completed'));
                die();
            }
        }
        else {
            echo json_encode(Array('Err'=>'Post was empty'));
        }
    break;
    default:
        echo json_encode(Array('Error' => "I don't see anything here"));
    break;
    }
}
else {
}
if(isset($_GET['Cheats'])) {
    $GameID = $_GET['Cheats'];
    $Database->showCheats($GameID);
}
?>