<?php
    class Utilities {
        public function inputFilter($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        public function Validation($string, $val_method) {
            try{
                switch($val_method) {
                    case 'key':
                    break;
                    case 'int':
                        if (!filter_var($string, FILTER_VALIDATE_INT) === false) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    break;
                    case 'char':
                    break;
                    case 'ip':
                        if (filter_var($string, FILTER_VALIDATE_IP, FILTER_FLAG_NO_RES_RANGE)) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    break;
                    case 'email':
                        if (filter_var($string, FILTER_VALIDATE_EMAIL)) {
                            return true;
                        } else {
                            return false;
                        }
                    break;
                    case 'alnum':
                        if (preg_match('/[\^£$%&*()}{@#~><>|=_+¬-]/', $string)){
                            return false;
                        } else {
                            return true;
                        }
                    break;
                    default:
                    return false;
                }
                return $string;
            }
            catch (Exception $e) {
                return false;
            }
        }
    }
?>