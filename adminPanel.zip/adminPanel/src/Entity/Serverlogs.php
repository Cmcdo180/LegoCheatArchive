<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Serverlogs
 *
 * @ORM\Table(name="serverlogs")
 * @ORM\Entity
 */
class Serverlogs
{
    /**
     * @var int
     *
     * @ORM\Column(name="logID", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $logid;

    /**
     * @var string
     *
     * @ORM\Column(name="Referrer", type="string", length=255, nullable=false)
     */
    private $referrer;

    /**
     * @var string
     *
     * @ORM\Column(name="SourceIP", type="string", length=255, nullable=false)
     */
    private $sourceip;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="TimeStamp", type="datetime", nullable=false)
     */
    private $timestamp;

    /**
     * @var string
     *
     * @ORM\Column(name="sessionID", type="string", length=255, nullable=false)
     */
    private $sessionid;

    /**
     * @var string
     *
     * @ORM\Column(name="requestedURL", type="string", length=255, nullable=false)
     */
    private $requestedurl;

    /**
     * @var string
     *
     * @ORM\Column(name="method", type="string", length=255, nullable=false)
     */
    private $method;

    public function getLogid(): ?int
    {
        return $this->logid;
    }

    public function getReferrer(): ?string
    {
        return $this->referrer;
    }

    public function setReferrer(string $referrer): self
    {
        $this->referrer = $referrer;

        return $this;
    }

    public function getSourceip(): ?string
    {
        return $this->sourceip;
    }

    public function setSourceip(string $sourceip): self
    {
        $this->sourceip = $sourceip;

        return $this;
    }

    public function getTimestamp(): ?\DateTimeInterface
    {
        return $this->timestamp;
    }

    public function setTimestamp(\DateTimeInterface $timestamp): self
    {
        $this->timestamp = $timestamp;

        return $this;
    }

    public function getSessionid(): ?string
    {
        return $this->sessionid;
    }

    public function setSessionid(string $sessionid): self
    {
        $this->sessionid = $sessionid;

        return $this;
    }

    public function getRequestedurl(): ?string
    {
        return $this->requestedurl;
    }

    public function setRequestedurl(string $requestedurl): self
    {
        $this->requestedurl = $requestedurl;

        return $this;
    }

    public function getMethod(): ?string
    {
        return $this->method;
    }

    public function setMethod(string $method): self
    {
        $this->method = $method;

        return $this;
    }


}
