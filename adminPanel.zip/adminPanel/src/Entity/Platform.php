<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Platform
 *
 * @ORM\Table(name="platform")
 * @ORM\Entity
 */
class Platform
{
    /**
     * @var int
     *
     * @ORM\Column(name="platformID", type="integer", nullable=false, options={"unsigned"=true})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $platformid;

    /**
     * @var string
     *
     * @ORM\Column(name="platformName", type="string", length=255, nullable=false)
     */
    private $platformname;

    public function getPlatformid(): ?int
    {
        return $this->platformid;
    }

    public function getPlatformname(): ?string
    {
        return $this->platformname;
    }

    public function setPlatformname(string $platformname): self
    {
        $this->platformname = $platformname;

        return $this;
    }


}
