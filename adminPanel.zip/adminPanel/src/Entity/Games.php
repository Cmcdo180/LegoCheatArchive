<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Games
 *
 * @ORM\Table(name="games")
 * @ORM\Entity
 */
class Games
{
    /**
     * @var int
     *
     * @ORM\Column(name="gameID", type="integer", nullable=false, options={"unsigned"=true})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $gameid;

    /**
     * @var string
     * @Assert\Regex(
     *      pattern = "/^[a-zA-Z0-9-_: ]+$/",
     *      message = "Aplha Numbers Only"
     * )
     *
     * @ORM\Column(name="gameTitle", type="string", length=255, nullable=false)
     * @Assert\NotBlank
     */
    private $gametitle;

    /**
     * @var string
     * @Assert\Regex(
     *      pattern = "/^[a-zA-Z- ]+$/",
     *      message = "Only Letters no numbers (Or special characters)"
     * )
     * @ORM\Column(name="gameGenre", type="string", length=255, nullable=false)
     * @Assert\NotBlank
     */
    private $gamegenre;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="gameReleaseDate", type="date", nullable=false)
     * @Assert\NotNull
     * @Assert\Date
     */
    private $gamereleasedate;

    /**
     * @var string
     *
     * @ORM\Column(name="gameDescription", type="string", length=65535, nullable=false)
     * @Assert\Regex(
     *      pattern = "/^[a-zA-Z0-9-_,:;""''?!(). ]+$/",
     *      message = "No dirty string entries thanks"
     * )
     */
    private $gamedescription;

    /**
     * @var string
     *
     * @ORM\Column(name="gamePic", type="string", length=255, nullable=false)
     * @Assert\Regex(
     *      pattern = "/^[a-zA-Z0-9-_.\/ ]+$/",
     *      message = "Enter file path, name and extention"
     * )
     */
    private $gamepic;

    public function getGameid(): ?int
    {
        return $this->gameid;
    }

    public function getGametitle(): ?string
    {
        return $this->gametitle;
    }

    public function setGametitle(string $gametitle): self
    {
        $this->gametitle = $gametitle;

        return $this;
    }

    public function getGamegenre(): ?string
    {
        return $this->gamegenre;
    }

    public function setGamegenre(string $gamegenre): self
    {
        $this->gamegenre = $gamegenre;

        return $this;
    }

    public function getGamereleasedate(): ?\DateTimeInterface
    {
        return $this->gamereleasedate;
    }

    public function setGamereleasedate(\DateTimeInterface $gamereleasedate): self
    {
        $this->gamereleasedate = $gamereleasedate;

        return $this;
    }

    public function getGamedescription(): ?string
    {
        return $this->gamedescription;
    }

    public function setGamedescription($gamedescription): self
    {
        $this->gamedescription = $gamedescription;

        return $this;
    }

    public function getGamepic(): ?string
    {
        return $this->gamepic;
    }

    public function setGamepic(string $gamepic): self
    {
        $this->gamepic = $gamepic;

        return $this;
    }


}
