<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Threads
 *
 * @ORM\Table(name="threads", indexes={@ORM\Index(name="platformID", columns={"platformID"}), @ORM\Index(name="gameID", columns={"gameID"})})
 * @ORM\Entity
 */
class Threads
{
    /**
     * @var int
     *
     * @ORM\Column(name="threadID", type="integer", nullable=false, options={"unsigned"=true})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $threadid;

    /**
     * @var \Games
     *
     * @ORM\ManyToOne(targetEntity="Games")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="gameID", referencedColumnName="gameID")
     * })
     */
    private $gameid;

    /**
     * @var \Platform
     *
     * @ORM\ManyToOne(targetEntity="Platform")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="platformID", referencedColumnName="platformID")
     * })
     */
    private $platformid;

    public function getThreadid(): ?int
    {
        return $this->threadid;
    }

    public function getGameid(): ?Games
    {
        return $this->gameid;
    }

    public function setGameid(?Games $gameid): self
    {
        $this->gameid = $gameid;

        return $this;
    }

    public function getPlatformid(): ?Platform
    {
        return $this->platformid;
    }

    public function setPlatformid(?Platform $platformid): self
    {
        $this->platformid = $platformid;

        return $this;
    }

    public function __toString()
    {
        return (string) $this->getThreadid();
    }
}
