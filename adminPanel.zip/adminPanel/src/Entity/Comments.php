<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Comments
 *
 * @ORM\Table(name="comments", indexes={@ORM\Index(name="UserIDB", columns={"UserID"}), @ORM\Index(name="postID", columns={"postID"})})
 * @ORM\Entity
 */
class Comments
{
    /**
     * @var int
     *
     * @ORM\Column(name="commentID", type="integer", nullable=false, options={"unsigned"=true})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $commentid;

    /**
     * @var string
     *
     * @ORM\Column(name="commentTitle", type="string", length=255, nullable=false)
     */
    private $commenttitle;

    /**
     * @var string
     *
     * @ORM\Column(name="commentDescription", type="text", length=65535, nullable=false)
     */
    private $commentdescription;

    /**
     * @var \Users
     *
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="UserID", referencedColumnName="userID")
     * })
     */
    private $userid;

    /**
     * @var \Posts
     *
     * @ORM\ManyToOne(targetEntity="Posts")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="postID", referencedColumnName="postID")
     * })
     */
    private $postid;

    public function getCommentid(): ?int
    {
        return $this->commentid;
    }

    public function getCommenttitle(): ?string
    {
        return $this->commenttitle;
    }

    public function setCommenttitle(string $commenttitle): self
    {
        $this->commenttitle = $commenttitle;

        return $this;
    }

    public function getCommentdescription(): ?string
    {
        return $this->commentdescription;
    }

    public function setCommentdescription(string $commentdescription): self
    {
        $this->commentdescription = $commentdescription;

        return $this;
    }

    public function getUserid(): ?Users
    {
        return $this->userid;
    }

    public function setUserid(?Users $userid): self
    {
        $this->userid = $userid;

        return $this;
    }

    public function getPostid(): ?Posts
    {
        return $this->postid;
    }

    public function setPostid(?Posts $postid): self
    {
        $this->postid = $postid;

        return $this;
    }


}
