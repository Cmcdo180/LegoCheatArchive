<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Posts
 *
 * @ORM\Table(name="posts", indexes={@ORM\Index(name="threadID", columns={"threadID"}), @ORM\Index(name="userID", columns={"userID"})})
 * @ORM\Entity
 */
class Posts
{
    /**
     * @var int
     *
     * @ORM\Column(name="postID", type="integer", nullable=false, options={"unsigned"=true})
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $postid;

    /**
     * @var string
     *
     * @Assert\Regex(
     *      pattern = "/^[a-zA-Z0-9-_: ]+$/",
     *      message = "Aplha Numbers Only"
     * )
     * 
     * @ORM\Column(name="postTitle", type="string", length=255, nullable=false)
     */
    private $posttitle;

    /**
     * @var string
     *
     * @Assert\Regex(
     *      pattern = "/^[a-zA-Z0-9-_,:;""''?!(). ]+$/",
     *      message = "No dirty string entries thanks"
     * )
     * 
     * @ORM\Column(name="postDescription", type="text", length=65535, nullable=false)
     */
    private $postdescription;

    /**
     * @var \DateTime
     * 
     * @Assert\NotNull 
     * @Assert\Date
     *
     * @ORM\Column(name="date", type="date", nullable=false)
     */
    private $date;

    /**
     * @var int
     *
     * @Assert\NotNull
     * 
     * @ORM\Column(name="rating", type="integer", nullable=false)
     */
    private $rating;

    /**
     * @var \Threads
     *
     * @Assert\NotNull
     * 
     * @ORM\ManyToOne(targetEntity="Threads")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="threadID", referencedColumnName="threadID")
     * })
     */
    private $threadid;

    /**
     * @var \Users
     *
     * @Assert\NotNull
     * 
     * @ORM\ManyToOne(targetEntity="Users")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="userID", referencedColumnName="userID")
     * })
     */
    private $userid;

    public function getPostid(): ?int
    {
        return $this->postid;
    }

    public function getPosttitle(): ?string
    {
        return $this->posttitle;
    }

    public function setPosttitle(string $posttitle): self
    {
        $this->posttitle = $posttitle;

        return $this;
    }

    public function getPostdescription(): ?string
    {
        return $this->postdescription;
    }

    public function setPostdescription(string $postdescription): self
    {
        $this->postdescription = $postdescription;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }

    public function getRating(): ?int
    {
        return $this->rating;
    }

    public function setRating(int $rating): self
    {
        $this->rating = $rating;

        return $this;
    }

    public function getThreadid(): ?Threads
    {
        return $this->threadid;
    }
    
    public function setThreadid(?Threads $threadid): self
    {
        $this->threadid = $threadid;

        return $this;
    }

    public function getUserid(): ?Users
    {
        return $this->userid;
    }

    public function setUserid(?Users $userid): self
    {
        $this->userid = $userid;

        return $this;
    }
}
