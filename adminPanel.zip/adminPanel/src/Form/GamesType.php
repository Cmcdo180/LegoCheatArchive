<?php

namespace App\Form;

use App\Entity\Games;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class GamesType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('gametitle')
            ->add('gamegenre')
            ->add('gamereleasedate', DateType::class, array(
                'input' => 'datetime',
                'widget' => 'single_text',
                // 'attr' => array('value'=>'2013-01-08')
                 ))
            ->add('gamedescription')
            ->add('gamepic')
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Games::class,
        ]);
    }
}
