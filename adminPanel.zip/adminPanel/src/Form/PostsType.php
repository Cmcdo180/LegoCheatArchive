<?php

namespace App\Form;

use App\Entity\Posts;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PostsType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('posttitle')
            ->add('postdescription')
            ->add('date', DateType::class, array(
                'input' => 'datetime',
                'widget' => 'single_text',
                // 'attr' => array('value'=>'2013-01-08')
                 ))
            ->add('rating', integerType::class, [])
            ->add('threadid', EntityType::class, [
                'class' => 'App\Entity\Threads',
                'choice_label' => 'threadid',
                'attr' => array('class'=>'browser-default')
            ])
            ->add('userid', EntityType::class, [
                'class' => 'App\Entity\Users',
                'choice_label' => 'userid',
                'attr' => array('class'=>'browser-default')
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Posts::class,
        ]);
    }
}
